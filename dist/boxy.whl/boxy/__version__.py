__title__ = 'boxy'
__version__ = '1.0.3'
__description__ = 'Native python API to access Box.com FTP'
__url__ = 'https://github.com/mmongeon-sym/boxy'
__author__ = 'mmongeon-sym'
__author_email__ = '36868044+mmongeon-sym@users.noreply.github.com'
__license__ = 'Unlicense, no rights reserved, https://unlicense.org/'


