

import os
import datetime
import functools
import sys
from types import ModuleType, FunctionType
from gc import get_referents
import hashlib
import tempfile


@functools.lru_cache(maxsize=1024, typed=True)
def is_databricks_env():
    if os.environ.get('DATABRICKS_RUNTIME_VERSION') is not None:
        return True
    else:
        return False


@functools.lru_cache(maxsize=1024, typed=True)
def databricks_version():
    if is_databricks_env() is True:
        return float(os.environ.get('DATABRICKS_RUNTIME_VERSION'))

    else:
        return None


@functools.lru_cache(maxsize=1024, typed=True)
def is_pyspark():
    try:
        import pyspark
        return True
    except ModuleNotFoundError as e:
        return False


@functools.lru_cache(maxsize=1024, typed=True)
def gettempdir():
    # https://docs.databricks.com/data/databricks-file-system.html#local-file-apis-for-deep-learning
    # https://docs.databricks.com/applications/deep-learning/data-prep/ddl-storage.html#prepare-storage-for-data-loading-and-model-checkpointing
    if is_databricks_env() is True:
        if databricks_version() >= 6.0:
            return '/dbfs/tmp/'
        elif databricks_version() in (5.5, 5.4):
            return '/dbfs/ml'
        else:
            return tempfile.gettempdir()
    else:
        return tempfile.gettempdir()


@functools.lru_cache(maxsize=1024, typed=True)
def SHA1_file(path: str, mtime: datetime.datetime, bytes: int):
    if mtime is None:
        raise AttributeError("mtime must be provided")
    if bytes is None:
        raise AttributeError("bytes must be provided")
    h = hashlib.sha1()
    b = bytearray(128 * 1024)
    mv = memoryview(b)
    if os.path.exists(path) is False:
        raise FileNotFoundError(path)
    with open(path, 'rb', buffering=0) as f:
        for n in iter(lambda: f.readinto(mv), 0):
            h.update(mv[:n])
    return str(h.hexdigest()).upper()


@functools.lru_cache(maxsize=1024, typed=True)
def MD5_file(path: str, mtime: datetime.datetime, bytes: int):
    if mtime is None:
        raise AttributeError("mtime must be provided")
    if bytes is None:
        raise AttributeError("bytes must be provided")

    h = hashlib.md5()
    b = bytearray(128 * 1024)
    mv = memoryview(b)
    if os.path.exists(path) is False:
        raise FileNotFoundError(path)
    with open(path, 'rb', buffering=0) as f:
        for n in iter(lambda: f.readinto(mv), 0):
            h.update(mv[:n])
    return str(h.hexdigest()).upper()



def getsizeof(obj):
    BLACKLIST = (type, ModuleType, FunctionType)
    """sum size of object & members."""
    if isinstance(obj, BLACKLIST):
        raise TypeError('getsize() does not take argument of type: ' + str(type(obj)))
    seen_ids = set()
    size = 0
    objects = [obj]
    while objects:
        need_referents = []
        for obj in objects:
            if not isinstance(obj, BLACKLIST) and id(obj) not in seen_ids:
                seen_ids.add(id(obj))
                size += sys.getsizeof(obj)
                need_referents.append(obj)
        objects = get_referents(*need_referents)
    return size


@functools.lru_cache(maxsize=1024, typed=True)
def humansize(nbytes: int):
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
    if nbytes == 0:
        return '0 B'
    i = 0
    while nbytes >= 1024 and i < len(suffixes) - 1:
        nbytes /= 1024.
        i += 1
    f = ('%.2f' % nbytes).rstrip('0').rstrip('.')
    return '%s %s' % (f, suffixes[i])
