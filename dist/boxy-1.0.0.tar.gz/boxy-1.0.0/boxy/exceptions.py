
class FTPFileNotFoundError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class BoxFileNotFoundError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class FTPFileExistsError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class BoxFileExistsError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class FTPFolderExistsError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class BoxFolderExistsError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class FTPFolderNotFoundError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors


class BoxFolderNotFoundError(Exception):
    def __init__(self, path, errors=None):
        # Call the base class constructor with the parameters it needs

        super().__init__(path)

        # Now for your custom code...
        self.errors = errors