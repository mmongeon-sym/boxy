# https://support.box.com/hc/en-us/articles/360043697414-Using-Box-with-FTP-or-FTPS
# https://support.box.com/hc/en-us/articles/360044194853-I-m-Having-Trouble-Using-FTP-with-Box

from io import BytesIO

import dataclasses
import re

import os
import pathlib
import ftplib
import datetime
import shutil
import time

import functools
import sys
from types import ModuleType, FunctionType
from gc import get_referents
import logging
import logging.config
import hashlib
import ssl
import tempfile
from .utils import  databricks_version, gettempdir, getsizeof, humansize, is_pyspark, is_databricks_env
from .logging import  disable_java_logging, get_logger

from .timer import  Timer
from .datetime import datetime_to_ftptime, parse_time, parse_unix_ts
disable_java_logging()
from .exceptions import FTPFileExistsError, FTPFolderExistsError, FTPFileNotFoundError, FTPFolderNotFoundError, BoxFileExistsError, BoxFileNotFoundError, BoxFolderExistsError, BoxFolderNotFoundError
import datetime
import functools

from .localFile import LocalFile
from .cachedFile import CachedFile
from .ftp import FTPClientMethods, FTP, FTPMethods



@dataclasses.dataclass(init=True, repr=False, eq=True, order=True, unsafe_hash=False, frozen=False)
class BoxFTP(FTPClientMethods):
    # https://docs.python.org/3/library/ftplib.html#ftplib.FTP
    username: str = dataclasses.field(init=True)
    password: str = dataclasses.field(init=True)
    host: str = dataclasses.field(init=False, default='107.152.24.220')
    port: int = dataclasses.field(init=False, default=21)
    timeout: int = dataclasses.field(init=True, default=120)
    ftp: ftplib.FTP_TLS = dataclasses.field(init=False)

    _is_box = True

    def __post_init__(self):
        self.connect(ftp=None)


