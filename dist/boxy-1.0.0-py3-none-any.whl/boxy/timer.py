import dataclasses
import datetime
import time

from bad_boxy.utils import humansize


@dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=False, frozen=False)
class Timer(object):
    start_dt: datetime.datetime = dataclasses.field(init=False, default=None)
    end_dt: datetime.datetime = dataclasses.field(init=False, default=None)
    duration: (datetime.timedelta, None) = dataclasses.field(init=False, default=None)
    running: bool = dataclasses.field(init=False, default=None)
    finished: bool = dataclasses.field(init=False, default=None)
    tz: datetime.timezone = dataclasses.field(init=False,
                                              default=datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo)
    init_dt: datetime.datetime = dataclasses.field(init=False, default=None)
    format: str = dataclasses.field(init=False, default='%Y%m%dT%H:%M:%S.%f%z')
    items: int = dataclasses.field(init=False, default=None)
    bytes: int = dataclasses.field(init=False, default=None)
    item_name: str = dataclasses.field(init=False, default='items')

    def __repr__(self):
        if self.status == 'STARTED':
            return f"Timer(started='{self.start_dt.isoformat(sep='T')}', duration='{(self.now_dt - self.start_dt)}')"
        elif self.status == 'INIT':
            return f"Timer(initialized='{self.init_dt.isoformat(sep='T')}')"
        elif self.status == 'FINISHED':
            msg = [f"duration='{self.duration_str}'"]
            if self.bytes is not None:
                msg.append(f"size='{self.bytes_str}'")
                msg.append(f"speed='{self.bytes_per_second_str}'")
            if self.items is not None:
                msg.append(f"iops='{self.items_per_second_str}'")
            msg_str = ", ".join(msg)
            return f"Timer(finished='{self.end_dt.isoformat(sep='T')}', {msg_str})"
        else:
            return f"Timer(status='{self.status}', '{self.duration_str})"

    @property
    def status(self):
        if self.running is None and self.finished is None:
            return "INITIALIZED"
        if self.running is True and self.finished is not True:
            return "STARTED"
        if self.running is False and self.finished is True:
            return "FINISHED"

    @property
    def now_dt(self):
        return datetime.datetime.now(tz=self.tz)

    def start(self):
        self.start_dt = self.now_dt
        self.running = True
        self.finished = False

    def __post_init__(self):
        self.init_dt = datetime.datetime.now(tz=self.tz)

    def stop(self,
             n_items: int = None,
             n_bytes: int = None,
             item_name: str = None
             ):
        if n_items is not None and isinstance(n_items, (int, float)):
            self.items = n_items
        if n_bytes is not None and isinstance(n_bytes, int):
            self.bytes = n_bytes
        if item_name is not None and isinstance(item_name, str):
            self.item_name = item_name
        self.running = False
        self.finished = True
        if self.end_dt is None:
            self.end_dt = datetime.datetime.now(tz=self.tz)
        if self.duration is None:
            self.duration = self.end_dt - self.start_dt

    @property
    def bytes_str(self):
        if self.bytes is not None:
            return humansize(self.bytes)

    @property
    def items_per_second(self):
        if self.items is not None and self.duration is not None:
            return round(float((self.items / float(self.duration_seconds))), 1)

    @property
    def items_per_second_str(self):
        if self.items is not None and self.duration is not None:
            return str(self.items_per_second) + " " + self.item_name + "/s"

    @property
    def bytes_per_second(self):
        if self.bytes is not None and self.duration is not None:
            return round(float(self.bytes) / float(self.duration_seconds), 1)

    @property
    def bytes_per_second_str(self):
        if self.bytes is not None and self.duration is not None:
            return humansize(self.bytes_per_second) + "/s"

    @property
    def megabytes_per_second(self):
        if self.bytes is not None and self.duration is not None:
            return round(float(self.bytes) / float(self.duration_seconds) / 1024 / 1024, 1)

    @property
    def megabytes_per_second_str(self):
        if self.bytes is not None and self.duration is not None:
            return str(self.megabytes_per_second) + " MB/s"

    @property
    def bits_per_second(self):
        if self.bytes is not None and self.duration is not None:
            return round(float(self.bytes * 8) / float(self.duration_seconds), 1)

    @property
    def megabits_per_second(self):
        if self.bytes is not None and self.duration is not None:
            return round(float(self.bytes * 8 / 1048576) / float(self.duration_seconds), 1)

    @property
    def megabits_per_second_str(self):
        if self.bytes is not None and self.duration is not None:
            return str(self.megabits_per_second) + " Mbit/s"

    @property
    def duration_seconds(self):
        if self.duration is not None:
            return float(self.duration.total_seconds())
        else:
            return None

    @property
    def duration_str(self):
        if self.duration is not None:
            return str(self.duration)[:-3]

    def strftime(self, object: datetime.datetime, format: (str, None) = None):
        if format is None:
            format = self.format
        return object.strftime(fmt=format)

    def humansize(self, bytes: int):
        if bytes is not None and isinstance(bytes, int) or isinstance(object, float):
            suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
            if bytes == 0:
                return '0 B'
            i = 0
            while bytes >= 1024 and i < len(suffixes) - 1:
                bytes /= 1024.
                i += 1
            f = ('%.2f' % bytes).rstrip('0').rstrip('.')
            return '%s %s' % (f, suffixes[i])

    def __enter__(self):
        """

        Automatically start the timer when used as a context manager.
        Executes self.start() when entered

        Example:
            with Timer(action='Wrote', item_name='lines', log=True) as t:
                .....

        Returns:
            self (:obj:`Timer`): Returns it self as a context manager.

        """
        if hasattr(self, 'running') and self.running is True:
            pass
        else:
            self.start()
            return self

    def __exit__(self, *args):
        """
        Automatically stop the timer when used as a context manager.
        Executes self.stop() when exited

        Returns:
            :obj:`None`: :obj:`None`

        """

        self.stop()

    def sleep(self, seconds: int):
        """
        Artificially add processing time to a Timer by executing time.sleep for N seconds.

        Parameters:
            seconds (:obj:`int`): Number of seconds to sleep using time.sleep

        Returns:
            :obj:`None`: :obj:`None`
        """
        time.sleep(seconds)

