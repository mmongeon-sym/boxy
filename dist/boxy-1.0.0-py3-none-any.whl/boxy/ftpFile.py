
from io import BytesIO

import dataclasses
import re

import os
import pathlib
import ftplib
import datetime
import shutil
import time

import functools
import sys
from types import ModuleType, FunctionType
from gc import get_referents
import logging
import logging.config
import hashlib
import ssl
import tempfile
from .utils import  databricks_version, gettempdir, getsizeof, humansize, is_pyspark, is_databricks_env
from .logging import  disable_java_logging, get_logger

from .timer import  Timer
from .datetime import datetime_to_ftptime, parse_time, parse_unix_ts
disable_java_logging()
from .exceptions import FTPFileExistsError, FTPFolderExistsError, FTPFileNotFoundError, FTPFolderNotFoundError, BoxFileExistsError, BoxFileNotFoundError, BoxFolderExistsError, BoxFolderNotFoundError
import datetime
import functools

from .localFile import LocalFile
from .cachedFile import CachedFile
from .ftp import FTPClientMethods, FTP, FTPMethods


class FTPFileMethods(FTPMethods):
    ftp: ftplib.FTP_TLS = NotImplemented
    path: str = NotImplemented

    directory: str = NotImplemented
    name: str = NotImplemented
    extension: str = NotImplemented

    bytes: int = NotImplemented
    size: str = NotImplemented

    # md5: str = dataclasses.field(init=False)
    ctime: datetime.datetime = NotImplemented
    mtime: datetime.datetime = NotImplemented
    exists: bool = NotImplemented
    type: str = NotImplemented
    _md5: str = NotImplemented

    obj: dataclasses.InitVar[tuple] = NotImplemented

    _is_box: bool = NotImplemented

    def __init__(self, ftp: ftplib.FTP_TLS, path: str, obj: tuple):
        raise NotImplementedError

    def __repr__(self,
                 size: bool = True,
                 mtime: bool = False,
                 ctime: bool = False,
                 exists: bool = True
                 ):
        if self.exists is True:
            msgs = []
            if exists is True and self.exists is not None:
                msgs.append(f"exists={self.exists}")
            if size is True and self.size is not None:
                msgs.append(f"size='{self.size}'")
            if mtime is True and self.mtime is not None:
                msgs.append(f"mtime='{self.mtime}'")
            if ctime is True and self.ctime is not None:
                msgs.append(f"ctime='{self.ctime}'")

            if len(msgs) > 0:
                msgs_str = ", ".join(msgs)
                return f"{self.__class__.__name__}('{self.path}', {msgs_str})"
            else:
                return f"{self.__class__.__name__}('{self.path}')"
        else:
            return f"{self.__class__.__name__}('{self.path}', exists=False)"
            # return f"FTPFile('{self.path}', exists={self.exists})"

    def __str__(self,
                size: bool = True,
                mtime: bool = False,
                ctime: bool = False,
                exists: bool = True
                ):
        return self.__repr__(size=size, mtime=mtime, ctime=ctime, exists=exists)

    def __post_init__(self, obj: tuple):
        raise NotImplementedError

    def initialize(self, obj: tuple):
        parts = pathlib.PurePosixPath(self.path)
        self.directory = str(parts.parent)
        self.name = str(parts.name)
        self.extension = str(parts.suffix)

        if obj is None:
            obj = self._get_raw_object(ftp=self.ftp, path=self.path, type='file')

        self.exists = False
        if obj is not None:
            assert obj[0] == self.name
            assert obj[1]['type'] == 'file'
            assert 'modify' in obj[1]
            assert 'create' in obj[1]
            if obj[1]['modify'] != '19700131000000.000' and obj[1]['create'] != '19700131000000.000':
                self.exists = True
            self.bytes = int(obj[1]['size'])
            self.size = humansize(self.bytes)
            self.ctime = parse_time(obj[1]['create'])
            self.mtime = parse_time(obj[1]['modify'])

            # TODO: Add call to get MD5

    @classmethod
    def from_obj(cls,
                 ftp: ftplib.FTP_TLS,
                 obj: tuple,
                 parent_dir: str
                 ):
        """

        from an ftplib.File object
            ex. ('Sapphire End User Documentation',
                    {   'size': '7327748',
                        'modify': '20191018204619.000',
                        'create': '20180412221908.000',
                        'type': 'dir'
                    }
                )
        """

        assert obj[1]['type'] == 'file'
        if parent_dir[-1] != "/":
            parent_dir = parent_dir + "/"
        path = parent_dir + obj[0]

        return cls(ftp=ftp,
                   path=path,
                   obj=obj
                   )

    def to_obj(self):
        return (self.name, {
                'create': datetime_to_ftptime(self.ctime),
                'modify': datetime_to_ftptime(self.mtime),
                'type':   'file',
                'size':   str(self.bytes)
                }
                )

    @classmethod
    def from_path(cls,
                  ftp: ftplib.FTP_TLS,
                  path: str
                  ):
        obj = cls._get_raw_object(ftp=ftp, path=path, type='file')
        return cls(ftp=ftp, path=path, obj=obj)

    def refresh(self, obj: tuple):
        self.clear()
        self.__post_init__(obj=obj)
        return self

    def clear(self):
        self.exists = False
        self.size = humansize(0)
        self.bytes = 0
        self.ctime = parse_time('19700131000000.000')
        self.mtime = parse_time('19700131000000.000')
        self._md5 = None
        return self

    def update_metadata(self, new_file):

        self.exists = new_file.exists
        self.mtime = new_file.mtime
        self.ctime = new_file.ctime
        self._md5 = new_file.md5
        self.path = new_file.path
        self.name = new_file.name
        self.directory = new_file.directory
        self.path = new_file.path
        self.extension = new_file.extension
        self.size = new_file.size

    def reset(self):
        self.clear()
        return self

    def assert_exists(self):
        if self.exists is False:
            if self._is_box is False:
                raise FTPFileNotFoundError(self.path)
            else:
                raise BoxFileNotFoundError(self.path)

    def assert_not_exists(self):
        if self.exists is True:
            if self._is_box is False:
                raise FTPFileExistsError(self.path)
            else:
                raise BoxFileExistsError(self.path)

    @property
    def md5(self):
        if self._md5 is not None and isinstance(self._md5, str):
            return self._md5
        else:
            self._md5 = self._get_md5(ftp=self.ftp, path=self.path, file=self,
                                      is_box=self._is_box)
        return self._md5

    def remove(self):
        if self.exists is True:
            file = self._delete_file(path=self.path, ftp=self.ftp, file=self,
                                     is_box=self._is_box)
            return file

        else:
            return self

    def makedirs(self):
        self._makedirs(ftp=self.ftp, path=self.directory, is_box=self._is_box)

    def rename(self, name):
        if self.exists is True:
            return self._rename_file(ftp=self.ftp, path=self.path, name=name, file=self,
                                     is_box=self._is_box)

    def read(self):
        return self._read_file(ftp=self.ftp, remote_path=self.path, remote_file=self,
                               is_box=self._is_box)

    def readlines(self):
        string = self.read()
        return string.splitlines()

    def write(self, string: str):
        return self._write_file(ftp=self.ftp, remote_path=self.path, string=string, remote_file=self,
                                is_box=self._is_box)

    def writelines(self, lines):
        if isinstance(lines, list) or isinstance(lines, tuple):
            string = "\n".join(lines)
        else:
            string = lines
        return self.write(string)

    def upload(self,
               path: str,
               set_mtime: bool = True,
               set_ctime: bool = False
               ):
        return self._upload_file(ftp=self.ftp,
                                 remote_path=self.path,
                                 local_path=path,
                                 remote_file=self,
                                 set_ctime=set_ctime,
                                 set_mtime=set_mtime,
                                 is_box=self._is_box
                                 )

    def download(self,
                 path: str,
                 set_mtime: bool = True,
                 set_ctime: bool = False
                 ):
        return self._download_file(ftp=self.ftp,
                                   local_path=path,
                                   remote_file=self,
                                   remote_path=self.path,
                                   set_ctime=set_ctime,
                                   set_mtime=set_mtime,
                                   is_box=self._is_box
                                   )

    def download_temp_file(self, set_mtime: bool = True,
                           set_ctime: bool = False):
        return self._download_temp_file(ftp=self.ftp,
                                        remote_file=self,
                                        remote_path=self.path,
                                        set_ctime=set_ctime,
                                        set_mtime=set_mtime,
                                        is_box=self._is_box
                                        )

    def set_mtime(self,
                  dt: datetime.datetime
                  ):
        file = self._set_modifed_dt(ftp=self.ftp,
                                    path=self.path,
                                    mtime=dt,
                                    file=self,
                                    is_box=self._is_box
                                    )
        self.mtime = file.mtime
        return file

    def set_ctime(self, dt: datetime.datetime):
        file = self._set_ctime(ftp=self.ftp,
                               path=self.path,
                               ctime=dt,
                               file=self,
                               is_box=self._is_box
                               )
        self.ctime = file.ctime
        return file

    def copy_obj(self):
        if self._is_box is True:
            return BoxFile(ftp=self.ftp, path=self.path, obj=self.to_obj())
        else:
            return FTPFile(ftp=self.ftp, path=self.path, obj=self.to_obj())

    def to_rdd(self, headers=True, inferSchema=True):
        """
        Return the result set as a DataFrame

        Parameters:

            index(:obj:`str`, optional): Column to be used as the index of the DataFrame, defaults to :obj:`None`



        """
        try:
            import pyspark
            temp_file = self.download_temp_file(set_mtime=True,
                                                set_ctime=False
                                                )

            from pyspark.sql import SparkSession

            t = Timer()
            t.start()
            sc = SparkSession.builder.getOrCreate()
            sc.conf.set("spark.sql.execution.arrow.enabled", "true")
            parts = pathlib.PurePosixPath(temp_file.path).parts[1]

            if pathlib.PurePosixPath(temp_file.path).parts[1] == 'dbfs':
                dbfs_path = temp_file.path.replace('/dbfs/', '')
            else:
                dbfs_path = temp_file.path

            rdd = sc.read.format('csv').options(header=headers, inferSchema=inferSchema).load(dbfs_path)

            n_rows = rdd.count()
            n_cols = len(rdd.columns)
            t.stop(n_items=n_rows,
                   n_bytes=temp_file.bytes,
                   item_name='rows'
                   )
            self.log.info("Returned RDD({n_cols}x{n_rows}), "
                          "{bytes_str} in {duration}, "
                          "{bits_sec}, "
                          "{bytes_sec}, "
                          "{bytes_sec}".format(n_cols=n_rows,
                                               n_rows=n_cols,
                                               bytes_str=t.bytes_str,
                                               duration=t.duration,
                                               bits_sec=t.bits_per_second,
                                               bytes_sec=t.bytes_per_second_str,
                                               rows_sec=t.items_per_second_str
                                               ))
            return rdd
        except ModuleNotFoundError as error:
            raise error



    def to_df(self, headers=True,
              columns: (bool, str, None, list, tuple) = None,
              parse_dates: (bool, str, None, list, tuple) =True,
              index_col: (str, None, list, tuple) = None):
        """
        Return the FTPFile as a Pandas DataFrame

        Parameters:

            index(:obj:`str`, optional): Column to be used as the index of the DataFrame, defaults to :obj:`None`

        Returns:
            :class:`pd.DataFrame`: Pandas DataFrame

        """

        # https://pandas.pydata.org/pandas-docs/version/0.24.2/reference/api/pandas.read_csv.html#pandas.read_csv
        try:
            import pandas as pd
        except ModuleNotFoundError as error:
            raise error

        temp_file = self.download_temp_file(set_mtime=True,
                                            set_ctime=False
                                            )

        if columns is not None and isinstance(columns, (list, tuple)) is True and len(columns) > 0:
            columns = columns
            usecols = columns
        else:
            columns = None
            usecols = None

        if headers is True:
            header = 'infer'
        if headers is False:
            header = 0
        else:
            header = 'infer'

        if parse_dates is True or (isinstance(parse_dates, (list, tuple)) is True and len(parse_dates) > 0):
            infer_datetime_format = True
        else:
            infer_datetime_format = False

        t = Timer()
        t.start()
        df = pd.read_csv(temp_file.path, sep=',',
                         header=header,
                         names=columns,
                         usecols=usecols,
                         index_col=index_col,
                         parse_dates=parse_dates,
                         infer_datetime_format=infer_datetime_format,
                         memory_map=True,
                         low_memory=False,
                         compression='infer'
                         )
        df.fillna(pd.np.nan, inplace=True)
        n_rows = df.shape[0]
        n_cols = len(df.columns)
        n_bytes = df.memory_usage(index=True, deep=False).sum()
        t.stop(n_items=int(n_rows),
               n_bytes=int(n_bytes),
               item_name='rows'
               )
        self.log.info("Returned DataFrame(cols={n_cols}, rows={n_rows}, size={bytes_str}) "
                      "in: '{duration}', '{bits_sec}', '{bytes_sec}', '{rows_sec}'".format(n_cols=n_cols,
                                                                                           n_rows=n_rows,
                                                                                           bytes_str=t.bytes_str,
                                                                                           duration=t.duration,
                                                                                           bits_sec=t.megabits_per_second_str,
                                                                                           bytes_sec=t.bytes_per_second_str,
                                                                                           rows_sec=t.items_per_second_str
                                                                                           ))

        return df


@dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=False, frozen=False)
class FTPFile(FTPFileMethods):
    ftp: ftplib.FTP_TLS = dataclasses.field(init=True)
    path: str = dataclasses.field(init=True)

    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)
    extension: str = dataclasses.field(init=False)

    bytes: int = dataclasses.field(init=False, default=0)
    size: str = dataclasses.field(init=False, default=humansize(0))

    # md5: str = dataclasses.field(init=False)
    ctime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    mtime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    exists: bool = dataclasses.field(init=False, default=None)
    type: str = dataclasses.field(init=False, default='file')
    _md5: str = dataclasses.field(init=False, default=None)

    obj: dataclasses.InitVar[tuple] = None

    _is_box = False

    def __post_init__(self,
                      obj: tuple
                      ):
        self.initialize(obj=obj)

