# https://support.box.com/hc/en-us/articles/360043697414-Using-Box-with-FTP-or-FTPS
# https://support.box.com/hc/en-us/articles/360044194853-I-m-Having-Trouble-Using-FTP-with-Box

from io import BytesIO

import dataclasses
import re

import os
import pathlib
import ftplib
import datetime
import shutil
import time

import functools
import sys
from types import ModuleType, FunctionType
from gc import get_referents
import logging
import logging.config
import hashlib
import ssl
import tempfile
from .utils import  databricks_version, gettempdir, getsizeof, humansize, is_pyspark, is_databricks_env
from .logging import  disable_java_logging, get_logger

from .timer import  Timer
from .datetime import datetime_to_ftptime, parse_time, parse_unix_ts
disable_java_logging()
from .exceptions import FTPFileExistsError, FTPFolderExistsError, FTPFileNotFoundError, FTPFolderNotFoundError, BoxFileExistsError, BoxFileNotFoundError, BoxFolderExistsError, BoxFolderNotFoundError
import datetime
import functools

from .localFile import LocalFile
from .cachedFile import CachedFile
from .boxFile import BoxFile
from .ftpFile import FTPFile
from .boxFolder import BoxFolder
from .ftpFolder import FTPFolder

class FTPMethods(object):
    log = get_logger()

    @classmethod
    def _get_obj(cls, ftp: ftplib.FTP_TLS, path: str, is_box: bool = False):
        parts = pathlib.PurePosixPath(path)
        for obj in ftp.mlsd(parts.parent):
            if obj[0] == parts.name and obj[1]['create'] != '19700131000000.000':
                if obj[1]['type'] == 'file':
                    if is_box is True:
                        return BoxFile.from_obj(ftp=ftp, obj=obj, parent_dir=str(parts.parent))
                    else:
                        return FTPFile.from_obj(ftp=ftp, obj=obj, parent_dir=str(parts.parent))
                elif obj[1]['type'] == 'dir':
                    if is_box is True:
                        return BoxFolder.from_obj(ftp=ftp, obj=obj, parent_dir=str(parts.parent))
                    else:
                        return FTPFolder.from_obj(ftp=ftp, obj=obj, parent_dir=str(parts.parent))

                return obj
        return None

    @classmethod
    def _get_raw_object(cls, ftp: ftplib.FTP_TLS, path: str, type: str):

        parts = pathlib.PurePosixPath(path)
        for obj in ftp.mlsd(parts.parent):
            if obj[0] == parts.name and obj[1]['create'] != '19700131000000.000' and obj[1]['type'] == type:
                return obj
        if str(type) == 'file':
            obj = (parts.name, {
                    'create': '19700131000000.000',
                    'modify': '19700131000000.000',
                    'type':   'file',
                    'size':   str(0)
                    }
                   )
            return obj
        if str(type) == 'dir':
            obj = (parts.name, {
                    'create': '19700131000000.000',
                    'modify': '19700131000000.000',
                    'type':   'dir',
                    'size':   str(0)
                    }
                   )
            return obj
        return None

    @classmethod
    def _get_file(cls,
                  ftp: ftplib.FTP_TLS,
                  path: str,
                  is_box: bool = False
                  ):
        if is_box is True:
            ClassTypeFile = BoxFile
        else:
            ClassTypeFile = FTPFile

        return ClassTypeFile.from_path(ftp=ftp, path=path)

    @classmethod
    def _get_folder(cls, ftp: ftplib.FTP_TLS, path: str, is_box: bool = False):
        if is_box is True:
            ClassTypeFile = BoxFolder
        else:
            ClassTypeFile = FTPFolder
        return ClassTypeFile.from_path(ftp=ftp, path=path)

    @classmethod
    def _path_exists(cls, ftp: ftplib.FTP_TLS, path: str):
        parts = pathlib.PurePosixPath(path)
        if path == "/":
            return True
        for f in ftp.mlsd(parts.parent):
            if f[0] == parts.name and f[1]['create'] != '19700131000000.000':
                return True
        return False

    @classmethod
    def _dir_exists(cls, ftp: ftplib.FTP_TLS, path: str):
        parts = pathlib.PurePosixPath(path)
        for f in ftp.mlsd(parts.parent):
            if f[0] == parts.name and f[1]['create'] != '19700131000000.000' and f[1]['type'] == 'dir':
                return True
        return False

    @classmethod
    def _file_exists(cls, ftp: ftplib.FTP_TLS, path: str):
        parts = pathlib.PurePosixPath(path)
        for f in ftp.mlsd(parts.parent):
            if f[0] == parts.name and f[1]['create'] != '19700131000000.000' and f[1]['type'] == 'file':
                return True
        return False

    @classmethod
    def __list_objs(cls, ftp: ftplib.FTP_TLS, path: str = '.'):
        items = []
        if path == '.':
            path = '/'
        if len(path) > 1 and path[-1] != '/':
            path = path + "/"
        parent_dir = path
        for obj in ftp.mlsd(path):
            if obj[1] not in ('.', '..'):
                items.append(obj)
        items = sorted(items, key=lambda x: x[1]['modify'], reverse=True)
        return items

    @classmethod
    def _list_objs(cls, ftp: ftplib.FTP_TLS, path: str = '.', is_box: bool = False):
        if is_box is True:
            ClassTypeFile = BoxFile
            ClassTypeFolder = BoxFolder
        else:
            ClassTypeFile = FTPFile
            ClassTypeFolder = FTPFolder
        items = []
        if path == '.':
            path = '/'
        if len(path) > 1 and path[-1] != '/':
            path = path + "/"
        parent_dir = path
        for obj in ftp.mlsd(path):
            if obj[0] not in ('.', '..'):
                if obj[1]['type'] == 'file':
                    file = ClassTypeFile.from_obj(ftp=ftp, obj=obj, parent_dir=parent_dir)
                    items.append(file)
                if obj[1]['type'] == 'dir':
                    folder = ClassTypeFolder.from_obj(ftp=ftp, obj=obj, parent_dir=parent_dir)
                    items.append(folder)
        items = sorted(items, key=lambda x: x.mtime, reverse=True)
        return items

    @classmethod
    def _list_files(cls, ftp: ftplib.FTP_TLS, path: str = '.', is_box: bool = False):
        items = []
        for item in cls._list_objs(ftp=ftp, path=path, is_box=is_box):
            if item.type == 'file':
                items.append(item)
        return items

    @classmethod
    def _list_dirs(cls, ftp: ftplib.FTP_TLS, path: str = '.', is_box: bool = False):
        items = []
        for item in cls._list_objs(ftp=ftp, path=path, is_box=is_box):
            if item.type == 'dir':
                items.append(item)
        return items

    @classmethod
    def _list_filenames(cls, ftp: ftplib.FTP_TLS, path: str = '.', is_box: bool = False):
        folders = []
        for file in cls._list_files(ftp, path=path, is_box=is_box):
            folders.append(file.name)
        return folders

    @classmethod
    def _list_dirnames(cls, ftp: ftplib.FTP_TLS, path: str = '.', is_box: bool = False):
        folders = []
        for folder in cls._list_dirs(ftp, path=path, is_box=is_box):
            folders.append(folder.name)
        return folders

    @classmethod
    def _makedirs(cls, ftp: ftplib.FTP_TLS, path: str, is_box: bool = False):
        parts = pathlib.PurePosixPath(path)
        if cls._path_exists(ftp, path) is False:
            iter_dir = "/"
            ftp.cwd(iter_dir)
            for subdir in parts.parent.parts[1:]:
                folders = [obj for obj in ftp.mlsd(iter_dir) if obj[1]['type'] == 'dir']
                folder_names = [n[0] for n in folders]
                if subdir not in folder_names:
                    # cls.log.info(f"Directory does not exist yet: {subdir}")
                    ftp.mkd(subdir)
                    # cls.log.info(f"Created directory: {subdir}")
                ftp.cwd(subdir)
                iter_dir = iter_dir + "/" + subdir
            # cls.log.info(f"Created directory: {iter_dir}")
        folder = cls._get_obj(ftp, path, is_box=is_box)
        return folder

    @classmethod
    def _get_temp_path(self,
                       ftp: ftplib.FTP_TLS,
                       remote_path: str,
                       remote_file=None,
                       is_box: bool = False
                       ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if remote_file is not None and isinstance(remote_file, FileClassType):
            remote_file = remote_file
        else:
            remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        temp_dir = gettempdir()
        temp_dir_lib = os.path.join(temp_dir, 'ftplib')
        temp_dir_host = os.path.join(temp_dir_lib, ftp.host)

        parts = pathlib.PurePosixPath(remote_path)
        name = parts.stem + '__' + remote_file.md5 + parts.suffix
        path = os.path.join(temp_dir_host, name)

        return path

    @classmethod
    def _download_temp_file(self,
                            ftp: ftplib.FTP_TLS,
                            remote_path: str,
                            remote_file=None,
                            set_ctime=False,
                            set_mtime=True,
                            is_box: bool = False):
        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if remote_file is not None and isinstance(remote_file, FileClassType):
            remote_file = remote_file
        else:
            remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        remote_file.assert_exists()

        temp_dir = gettempdir()
        temp_dir_lib = os.path.join(temp_dir, 'ftplib')
        temp_dir_host = os.path.join(temp_dir_lib, ftp.host)

        parts = pathlib.PurePosixPath(remote_file.path)
        name = parts.stem + '__' + remote_file.md5 + parts.suffix
        path = os.path.join(temp_dir_host, name)

        if os.path.exists(path) is True:
            temp_file = CachedFile(path=path)
            print(f"{temp_file.__repr__(size=True)}: is already cached")
            return CachedFile(path=path)
        new_file = self._download_file(ftp=ftp,
                                       local_path=path,
                                       remote_path=remote_path,
                                       remote_file=remote_file,
                                       set_ctime=set_ctime,
                                       set_mtime=set_mtime,
                                       is_box=is_box
                                       )

        temp_file = CachedFile(path=path)
        return temp_file

    @classmethod
    def _download_file(cls,
                       ftp: ftplib.FTP_TLS,
                       remote_path: str,
                       local_path: str,
                       remote_file=None,
                       set_ctime=False,
                       set_mtime=True,
                       is_box: bool = False
                       ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        local_file = LocalFile(local_path)
        if remote_file is not None and isinstance(remote_file, FileClassType):
            remote_file = remote_file
        else:
            remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        remote_file.assert_exists()

        if local_file.exists is True:
            remote_md5 = remote_file.md5
            local_md5 = local_file.md5
            copy_local_file = LocalFile(path=local_path)

            if local_file.mtime > remote_file.mtime:
                cls.log.warning(f"{local_file.__repr__(mtime=True, size=True)} "
                                f"is newer than: {remote_file.__repr__(mtime=True, size=True)} "
                                f"by: {str(local_file.mtime - remote_file.mtime)}")
            if local_file.size > remote_file.size:
                cls.log.warning(f"{local_file.__repr__(size=True, exists=False)} "
                                f"is larger than: {remote_file.__repr__(size=True, exists=False)} "
                                f"by: {humansize(local_file.bytes - remote_file.bytes)}")

            if local_md5 == remote_md5:
                cls.log.info(f"{local_file.__repr__(size=False, exists=False)} "
                             f"and {remote_file.__repr__(exists=False, size=False)} "
                             f"have the same MD5: '{local_md5}'")
                cls.log.info(
                        f"No files were downloaded. "
                        f"{local_file.__repr__(exists=False, size=False)} "
                        f"and {remote_file.__repr__(size=False, exists=False)} "
                        f"are the same file.")
                return local_file
            if local_md5 != remote_md5:
                remote_file = remote_file.remove()
                cls.log.info(f"Removed existing: {copy_local_file.__repr__(size=True, exists=False)}")

        local_file.makedirs()
        with Timer() as t:
            with open(local_file.path, 'wb') as outfile:
                ftp.cwd("/")
                ftp.cwd(remote_file.directory)
                ftp.retrbinary(f'RETR {remote_file.name}', outfile.write)
            t.stop(n_bytes=remote_file.bytes)
        new_local_file = LocalFile(local_path)
        if set_mtime is True:
            new_local_file = new_local_file.set_mtime(dt=remote_file.mtime)
        if set_ctime is True:
            new_local_file = new_local_file.set_ctime(dt=remote_file.ctime)
        if new_local_file.exists is False:
            cls.log.error(f"Failed to download: {remote_file.__repr__(exists=True, size=True)} "
                          f"to {new_local_file.__repr__(exists=False, size=False)}")
            new_local_file.assert_exists()
        if new_local_file.exists is True:
            cls.log.info(
                    f"Downloaded {remote_file.__repr__(exists=False, size=True)} "
                    f"to {new_local_file.__repr__(size=False, exists=False)} "
                    f"in: '{t.duration_str}', "
                    f"('{t.bytes_str}', "
                    f"'{t.megabits_per_second_str}', "
                    f"'{t.megabytes_per_second_str}'")
            return new_local_file

    @classmethod
    def _upload_file(cls,
                     ftp: ftplib.FTP_TLS,
                     remote_path: str,
                     local_path: str,
                     remote_file=None,
                     set_ctime: bool = False,
                     set_mtime: bool = True,
                     is_box: bool = False
                     ):
        local_file = LocalFile(path=local_path)
        local_file.assert_exists()

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if remote_file is not None and isinstance(remote_file, FileClassType):
            remote_file = remote_file
        else:
            remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        cls.log.info(f"Uploading: {local_file.__repr__(size=True, exists=False)} "
                     f"to {remote_file.__repr__(exists=True, size=False)}")

        if remote_file.exists is True:
            remote_md5 = remote_file.md5
            local_md5 = local_file.md5
            copy_remote_file = remote_file.copy_obj()
            if remote_file.mtime > local_file.mtime:
                cls.log.warning(f"{remote_file.__repr__(mtime=True, size=True)} "
                                f"is newer than: {local_file.__repr__(mtime=True, size=True)} "
                                f"by: {str(remote_file.mtime - local_file.mtime)}")
            if remote_file.size > local_file.size:
                cls.log.warning(f"{remote_file.__repr__(size=True)} "
                                f"is larger than: {local_file.__repr__(size=True)} "
                                f"by: {humansize(remote_file.bytes - local_file.bytes)}")

            if local_md5 == remote_md5:
                cls.log.info(f"{remote_file.__repr__(size=False, exists=False)} "
                             f"and {local_file.__repr__(exists=False,size=False)} "
                             f"have the same MD5: '{local_md5}'")
                cls.log.info(
                    f"No files were uploaded. {remote_file.__repr__(exists=False, size=False)} "
                    f"and {local_file.__repr__( size=False, exists=False)} "
                    f"are the same file.")
                return remote_file
            if local_md5 != remote_md5:
                remote_file = remote_file.remove()
                cls.log.info(f"Removed existing: {copy_remote_file.__repr__(size=True, exists=False)}")

        remote_file.makedirs()
        with Timer() as t:
            with open(local_file.path, 'rb') as infile:
                ftp.cwd("/")
                ftp.cwd(remote_file.directory)
                ftp.storbinary(f'STOR {remote_file.name}', infile)
            t.stop(n_bytes=local_file.bytes)

        new_remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)
        if set_mtime is True:
            new_remote_file = new_remote_file.set_mtime(dt=local_file.mtime)
        if set_ctime is True:
            new_remote_file = new_remote_file.set_ctime(dt=local_file.ctime)

        remote_file.update_metadata(new_remote_file)

        if new_remote_file.exists is False:
            cls.log.error(f"Failed to upload: {local_file.__repr__(size=True, exists=True)} "
                          f"to {new_remote_file.__repr__(exists=False, size=False)}")
            new_remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)
            new_remote_file.assert_exists()
        if new_remote_file.exists is True:
            cls.log.info(f"Uploaded: {local_file.__repr__(size=True, exists=False)} "
                         f"to {new_remote_file.__repr__(exists=False, size=False)} "
                         f"in: '{t.duration_str}', "
                         f"'{t.megabits_per_second_str}', "
                         f"'{t.megabytes_per_second_str}'")
            return new_remote_file

    @classmethod
    def _read_file(cls,
                   ftp: ftplib.FTP_TLS,
                   remote_path: str,
                   remote_file=None,
                   is_box: bool = False
                   ):

        if is_box is True:
            ClassType = BoxFile
        else:
            ClassType = FTPFile

        if remote_file is not None and isinstance(remote_file, ClassType):
            remote_file = remote_file
        else:
            remote_file = ClassType.from_path(ftp=ftp, path=remote_path)
        bytesio = BytesIO()
        remote_file.assert_exists()

        cls.log.info(f"Reading: {remote_file.__repr__(exists=False, size=True)}")

        ftp.cwd("/")
        ftp.cwd(remote_file.directory)

        with Timer() as t:
            ftp.retrbinary(f'RETR {remote_file.name}', bytesio.write)
            string = bytesio.getvalue().decode('utf-8')
            t.stop(n_bytes=getsizeof(string))

        cls.log.info(f"Read {len(string.splitlines())} lines, "
                     f"{len(string)} chars "
                     f"from: {remote_file.__repr__(exists=False, size=True)} "
                     f"in: '{t.duration_str}', "
                     f"'{t.megabits_per_second_str}',"
                     f"'{t.megabytes_per_second_str}'"
                     )

    @classmethod
    def _write_file(cls,
                    ftp: ftplib.FTP_TLS,
                    remote_path: str,
                    string: str,
                    ctime: datetime.datetime = None,
                    mtime: datetime.datetime = None,
                    remote_file=None,
                    is_box: bool = False
                    ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if remote_file is not None and isinstance(remote_file, FileClassType):
            remote_file = remote_file
        else:
            remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        cls.log.info(f"Writing: {remote_file.__repr__(size=False, exists=False)} ")
        if remote_file.exists is True:
            copy_remote_file = remote_file.copy_obj()
            remote_file = remote_file.remove()
            cls.log.info(f"Removed existing: {copy_remote_file.__repr__(size=False, exists=False)}")

        remote_file.makedirs()
        ftp.cwd("/")
        ftp.cwd(remote_file.directory)
        with Timer() as t:
            ftp.storbinary(f'STOR {remote_file.name}', BytesIO(string.encode('utf-8')))
            t.stop(n_bytes=getsizeof(string))
        new_remote_file = FileClassType.from_path(ftp=ftp, path=remote_path)

        if mtime is not None and isinstance(mtime, datetime.datetime):
            new_remote_file = new_remote_file.set_mtime(dt=mtime)
        if ctime is not None and isinstance(mtime, datetime.datetime):
            new_remote_file = new_remote_file.set_mtime(dt=ctime)
        remote_file.update_metadata(new_remote_file)
        if new_remote_file.exists is False:
            cls.log.error(f"Failed to write "
                          f"{len(string.splitlines())} lines, "
                          f"{len(string)} chars "
                          f"to: {new_remote_file.__repr__(exists=False, size=False)}")
            new_remote_file.assert_exists()
        if new_remote_file.exists is True:
            cls.log.info(f"Wrote {len(string.splitlines())} lines, "
                         f"{len(string)} chars "
                         f"to: {remote_file.__repr__(size=True, exists=False)} "
                         f"in: '{t.duration_str}', "
                         f"'{t.megabits_per_second_str}', "
                         f"'{t.megabytes_per_second_str}'"
                         )
            return new_remote_file

    @classmethod
    def _delete_file(cls,
                     ftp: ftplib.FTP_TLS,
                     path: str,
                     file=None,
                     is_box: bool = False
                     ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if file is not None and isinstance(file, FileClassType):
            file = file
        else:
            file = FileClassType.from_path(ftp=ftp, path=path)

        if file.exists is True:
            old_file = file.copy_obj()
            with Timer() as t:
                ftp.cwd("/")
                ftp.cwd(file.directory)
                ftp.delete(file.name)
                t.stop()
            file = file.reset()
            cls.log.info(f"Removed: {old_file.__repr__(exists=False, size=True)} in: '{t.duration_str}'")

            return file
        else:
            return file

    @classmethod
    def _rename_file(cls,
                     ftp: ftplib.FTP_TLS,
                     path: str,
                     name: str,
                     file=None,
                     is_box: bool = True
                     ):
        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = FTPFile

        if file is not None and isinstance(file, FileClassType):
            file = file
        else:
            file = FileClassType.from_path(ftp=ftp, path=path)

        if file.exists is True:
            new_file = file.copy_obj()
            with Timer() as t:
                ftp.cwd("/")
                ftp.cwd(file.directory)
                ftp.rename(file.name, name)
                t.stop()
            new_file.name = name
            file = file.reset()
            cls.log.info(f"Renamed: {file.__repr__(exists=True, size=False)} "
                         f"to: {new_file.__repr__(exists=True, size=False)} "
                         f"in: '{t.duration_str}'")

            return new_file

        else:
            return file

    @classmethod
    def _delete_dir(cls,
                    ftp: ftplib.FTP_TLS,
                    path: str,
                    folder=None,
                    is_box: bool = True
                    ):
        if is_box is True:
            FolderClassType = BoxFolder
        else:
            FolderClassType = FTPFolder

        if folder is not None and isinstance(folder, FolderClassType):
            folder = folder
        else:
            folder = FolderClassType.from_path(ftp=ftp, path=path)

        folder.assert_exists()
        # TODO: Fix this
        new_folder = folder.copy_obj()
        with Timer() as t:
            ftp.cwd("/")
            ftp.cwd(folder.directory)
            ftp.rmd(folder.name)
            t.stop()
        new_folder.reset()
        cls.log.info(f"Removed: {folder.__repr__(size=True)} in: '{t.duration_str}'")
        return new_folder

    @classmethod
    def _connect(cls,
                 host: str,
                 port: int,
                 username: str,
                 password: str,
                 timeout: int = 120
                 ):
        try:
            with Timer() as t:
                context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
                context.verify_mode = ssl.CERT_REQUIRED
                # context.check_hostname = True
                context.load_default_certs()

                ftp = ftplib.FTP_TLS(timeout=10, context=context)
                ftp.connect(host=host, port=port, timeout=10)
                ftp.auth()
                ftp.prot_p()
                ftp.set_pasv(True)
                ftp.login(user=username, passwd=password, secure=True)
                ftp.timeout = timeout
                t.stop()
            cls.log.info(f"{username} Connected to '{host}:{port}' in '{t.duration_str}'")

            return ftp
        except ftplib.all_errors as e:
            raise e

    @classmethod
    def _is_connected(cls,
                      ftp: ftplib.FTP_TLS
                      ):
        if ftp is not None and isinstance(ftp, ftplib.FTP_TLS):
            try:
                cwd = ftp.pwd()
                return True
            except Exception as e:
                return False
        else:
            return False

    @classmethod
    def _close(cls,
               ftp: ftplib.FTP_TLS
               ):
        if cls._is_connected(ftp) is True:
            ftp.quit()

    @classmethod
    def _available_commands(cls,
                            ftp: ftplib.FTP_TLS
                            ):
        return [x.strip() for x in ftp.sendcmd('Feat').splitlines()[1:-1]]

    def _set_modifed_dt(self,
                        ftp: ftplib.FTP_TLS,
                        path: str,
                        mtime: datetime.datetime,
                        file=None,
                        is_box: bool = False
                        ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = BoxFile

        if file is not None and isinstance(file, FileClassType):
            file = file
        else:
            file = FileClassType.from_path(ftp=ftp, path=path)

        if file.exists is True:
            ftp.cwd('/')
            ftp.cwd(file.directory)
            dt_str = datetime_to_ftptime(mtime)
            ftp.sendcmd(f"MFMT {dt_str} {file.path}")
            file.mtime = mtime
        return file

    def _set_ctime(self,
                   ftp: ftplib.FTP_TLS,
                   path: str,
                   ctime: datetime.datetime,
                   file=None,
                   is_box: bool = False
                   ):

        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = BoxFile

        if file is not None and isinstance(file, FileClassType):
            file = file
        else:
            file = FileClassType.from_path(ftp=ftp, path=path)
        if file.exists is True:
            ftp.cwd('/')
            ftp.cwd(file.directory)
            dt_str = datetime_to_ftptime(ctime)
            ftp.sendcmd(f"MFCT {dt_str} {file.path}")
            file.mtime = ctime
        return file

    def _get_md5(self,
                 ftp: ftplib.FTP_TLS,
                 path: str,
                 file=None,
                 is_box: bool = False
                 ):
        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = BoxFile

        if file is not None and isinstance(file, FileClassType):
            file = file
        else:
            file = FileClassType.from_path(ftp=ftp, path=path)
        if file.exists is True:
            md5_str = str(ftp.sendcmd(f"MD5 {file.path}")).split(" ")[-1]
            return md5_str.upper()
        else:
            return None

    def _get_multiple_md5s(self,
                           ftp: ftplib.FTP_TLS,
                           paths: (list, tuple),
                           files: (list, tuple),
                           is_box: bool = False
                           ):
        if is_box is True:
            FileClassType = BoxFile
        else:
            FileClassType = BoxFile

        if files is not None and len(files) == len(paths):
            files = files
        else:
            files = []
            for path in paths:
                file = FileClassType.from_path(ftp=ftp, path=path)
                files.append(file)

        new_files = []
        for file in files:
            if file.exists is True:
                new_files.append(file)
        paths_str = ",".join([file.path for file in new_files])
        nnew_files = []
        if len(new_files) > 0:
            resp = str(ftp.sendcmd(f"MMD5 {paths_str}"))
            RE_MMD5 = re.compile(r".*([A-Za-z0-9]{32}).*")
            for idx, part in enumerate(resp.split(", ")):
                match = RE_MMD5.findall(part)[0]
                new_file = new_files[idx]
                new_file._md5 = match
                nnew_files.append(new_file)
            return nnew_files
        else:
            return nnew_files


class FTPClientMethods(FTPMethods):
    host: str = NotImplemented
    port: int = NotImplemented
    username: str = NotImplemented
    password: str = NotImplemented
    timeout: int = NotImplemented
    ftp: ftplib.FTP_TLS = NotImplemented

    _is_box = False

    def __init__(self, host: str, port: int, username: str, password: str):
        raise NotImplementedError

    def __repr__(self):
        return f"{self.__class__.__name__}('{self.host}:{self.port}')"

    @property
    def closed(self):
        if self._is_connected(ftp=self.ftp) is True:
            return False
        else:
            return True

    def close(self):
        if self.closed is False:
            self._close(ftp=self.ftp)
            self.log.info(f"{self.__repr__()}: Closed Connection")

    def connect(self,
                ftp: ftplib.FTP_TLS = None
                ):
        if ftp is not None and isinstance(ftp, ftplib.FTP_TLS):
            if self._is_connected(ftp) is True:
                self.ftp = ftp
        else:
            self.ftp = self._connect(host=self.host,
                                     username=self.username,
                                     password=self.password,
                                     port=self.port,
                                     timeout=self.timeout
                                     )
            return self.ftp

    def reset(self):
        if self.closed is False:
            self.close()
        self.connect(ftp=None)

    def new_connection(self):
        return FTP(username=self.username,
                   password=self.password,
                   host=self.host,
                   port=self.port,
                   timeout=self.timeout
                   )

    def file(self, path: str):
        if self._is_box is True:
            return BoxFile.from_path(ftp=self.ftp, path=path)
        else:

            return FTPFile.from_path(ftp=self.ftp, path=path)

    def folder(self, path: str):
        if self._is_box is True:
            return BoxFolder.from_path(ftp=self.ftp, path=path)
        else:

            return FTPFolder.from_path(ftp=self.ftp, path=path)

    def files(self, path: str = '/'):
        if path is None:
            path = '/'
        return self._list_files(ftp=self.ftp, path=path, is_box=self._is_box)

    def folders(self, path: str = '/'):
        if path is None:
            path = '/'
        return self._list_dirs(ftp=self.ftp, path=path, is_box=self._is_box)

    def list(self, path: str = '/'):
        if path is None:
            path = '/'
        return self._list_objs(ftp=self.ftp, path=path, is_box=self._is_box)

    def upload_file(self,
                    remote_path: str,
                    local_path: str,
                    remote_file=None,
                    set_ctime: bool = False,
                    set_mtime: bool = True,
                    is_box: bool = False):
        return self._upload_file(ftp=self.ftp,
                                 remote_path=remote_path,
                                 local_path=local_path,
                                 remote_file=remote_file,
                                 set_ctime=set_ctime,
                                 set_mtime=set_mtime,
                                 is_box=is_box
                                 )

    def download_file(self,
                      remote_path: str,
                      local_path: str,
                      remote_file=None,
                      set_ctime=False,
                      set_mtime=True,
                      is_box: bool = False
                      ):
        return self._download_file(ftp=self.ftp,
                                   remote_path=remote_path,
                                   local_path=local_path,
                                   remote_file=remote_file,
                                   set_ctime=set_ctime,
                                   set_mtime=set_mtime,
                                   is_box=is_box
                                   )

    def download_temp_file(self,
                           remote_path: str,
                           remote_file=None,
                           set_ctime=False,
                           set_mtime=True,
                           is_box: bool = False
                           ):
        return self._download_temp_file(ftp=self.ftp,
                                        remote_path=remote_path,
                                        remote_file=remote_file,
                                        set_ctime=set_ctime,
                                        set_mtime=set_mtime,
                                        is_box=is_box
                                        )


@dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=False, frozen=False)
class FTP(FTPClientMethods):
    # https://docs.python.org/3/library/ftplib.html#ftplib.FTP
    host: str = dataclasses.field(init=True)
    port: int = dataclasses.field(init=True)
    username: str = dataclasses.field(init=True)
    password: str = dataclasses.field(init=True)
    timeout: int = dataclasses.field(init=True, default=120)
    ftp: ftplib.FTP_TLS = dataclasses.field(init=False)

    _is_box = False

    def __post_init__(self):
        self.connect(ftp=None)
