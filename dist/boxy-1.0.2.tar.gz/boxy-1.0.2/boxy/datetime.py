import datetime
import functools


@functools.lru_cache(maxsize=1024, typed=True)
def parse_time(time_str: str):
    # ex parse_time('19700131000000.000')
    #    returns: datetime.datetime(1970, 1, 30, 17, 0, tzinfo=datetime.timezone(datetime.timedelta(days=-1,
    #    seconds=61200), 'Pacific Daylight Time'))

    return datetime.datetime.strptime(time_str + '000' + '+0000', '%Y%m%d%H%M%S.%f%z').astimezone(
            datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo)


@functools.lru_cache(maxsize=1024, typed=True)
def datetime_to_ftptime(dt: datetime.datetime):
    # ex parse_time('19700131000000.000')
    #    returns: datetime.datetime(1970, 1, 30, 17, 0, tzinfo=datetime.timezone(datetime.timedelta(days=-1,
    #    seconds=61200), 'Pacific Daylight Time'))
    dt_noz = dt.astimezone(datetime.timezone.utc)

    return dt_noz.strftime('%Y%m%d%H%M%S') + "." + dt_noz.strftime('%f')[0:3]


@functools.lru_cache(maxsize=1024, typed=True)
def parse_unix_ts(unix_time: str):
    # ex parse_time('1586345134')
    #    returns: datetime.datetime(1970, 1, 30, 17, 0, tzinfo=datetime.timezone(datetime.timedelta(days=-1,
    #    seconds=61200), 'Pacific Daylight Time'))

    return datetime.datetime.fromtimestamp(unix_time).replace(tzinfo=datetime.timezone.utc).astimezone(
            datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo)