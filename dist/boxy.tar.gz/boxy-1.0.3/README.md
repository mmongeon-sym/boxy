# boxy
 Native python API to access Box.com FTP



## Install

This package has not yet been published to PyPi but can be installed directly by referencing the URL to the latest version on Github. 

See: [Github Releases](https://github.com/mmongeon-sym/pipy/releases)

#### Install from Github (Latest Version)
```bash
pip install https://github.com/mmongeon-sym/boxy/releases/latest/download/boxy.tar.gz
```
or 

```bash 
pip install https://github.com/mmongeon-sym/boxy/releases/latest/download/boxy.whl
```
#### Uninstall
```bash
pip uninstall boxy -y
```

## Usage

#### Import
```bash
from pipy import Pipy
```

