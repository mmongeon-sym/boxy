import dataclasses
import ftplib

from .datetime import parse_time
from .logging import disable_java_logging
from .utils import humansize

disable_java_logging()
import datetime

from .ftpFile import FTPFileMethods

@dataclasses.dataclass(init=True, repr=False, eq=True, order=True, unsafe_hash=False, frozen=False)
class BoxFile(FTPFileMethods):
    ftp: ftplib.FTP_TLS = dataclasses.field(init=True)
    path: str = dataclasses.field(init=True)

    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)

    bytes: int = dataclasses.field(init=False, default=0)
    size: str = dataclasses.field(init=False, default=humansize(0))

    ctime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    mtime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    exists: bool = dataclasses.field(init=False, default=None)
    type: str = dataclasses.field(init=False, default='file')
    _md5: str = dataclasses.field(init=False, default=None)

    obj: dataclasses.InitVar[tuple] = None

    _is_box: bool = True

    # _fobj : BytesIO = None
    # _fobj_closed: bool = None
    #

    # _is_readable: bool = False
    # _is_writable: bool = False

    def __post_init__(self,
                      obj: tuple
                      ):
        self.initialize(obj=obj)
    #
    # def read(self):
    #
    # def _write_buffer_size(self):
    #     """Return current size of the write buffer in bytes."""
    #     # pylint: disable=protected-access
    #     if hasattr(self._fobj, "_wbuf_len"):
    #         # Python 2.6.3 - 2.7.5
    #         return self._fobj.
    #     elif hasattr(self._fobj, "_get_wbuf_len"):
    #         # Python 2.6 - 2.6.2. (Strictly speaking, all other
    #         # Python 2.6 versions have a `_get_wbuf_len` method, but
    #         # for 2.6.3 and up it returns `_wbuf_len`).
    #         return self._fobj._get_wbuf_len()
    #     else:
    #         # Fallback. In the context of `write` this means the file
    #         # appears to be unbuffered.
    #         return 0to
    #
    # def write(self, data: (bytes, bytearray, str), encoding='utf-8'):
    #
    #     # `BufferedWriter.write` has to return the number of written
    #     # bytes, but files returned from `socket.makefile` in Python 2
    #     # return `None`. Hence provide a workaround.
    #     old_buffer_byte_count = self._write_buffer_size()
    #     added_byte_count = len(bytes_or_bytearray)
    #     self._fobj.write(bytes_or_bytearray)
    #     new_buffer_byte_count = self._write_buffer_size()
    #     return (old_buffer_byte_count + added_byte_count -
    #             new_buffer_byte_count)
    #
    #
    # def writelines(self, lines):
    #     self._fobj.writelines(lines)
    #
    #
    # def open(self,  path, mode, buffering=None, encoding=None, errors=None,
    #           newline=None, rest=None):
    #
    #     self._fobj = BytesIO()
    #     if 'rb' in mode:
    #
    #         self.ftp.storbinary(f'RETR {self.path}', self._fobj.write)
    #         self._fobj .seek(offset=0)
    #
    #         string = self._fobj.getvalue().decode('utf-8')
    #         # t.stop(n_bytes=getsizeof(string))
    #         self.ftp.storbinary(f'STOR {self.path}', BytesIO(string.encode('utf-8')))
    #         # t.stop(
    #

    #     pass
    # elif 'r' in mode and 'rb' not in mode:
    #     pass
    # elif 'wb' in mode:
    #     pass
    # elif 'w' in mode and 'wb' not in mode:
    #     pass
    # else:
    #     raise AttributeError(f"param='mode' must be one of the following: 'r', 'rb', 'w', 'wb', not: {mode}<type={type(mode)}>")

    # @property
    # def closed(self):
    #     return self._fobj_closed
    #
    # def close(self):
    #     try:
    #         if self._fobj_closed is not True:
    #             self._fobj.close()
    #             self._fobj_closed = True
    #             self._fobj : (None, BytesIO) = None
    #     except Exception as e:
    #         self._fobj_closed = True
    #         pass

    # def __enter__(self):
    #     # Return `self`, so it can be accessed as the variable
    #     # component of the `with` statement.
    #     return self
    #
    # def __exit__(self, *args):
    #     # We don't need the `exc_*` arguments here
    #     # pylint: disable=unused-argument
    #     self.close()
    #     # Be explicit
