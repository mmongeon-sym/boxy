# boxy
 Native python API to access Box.com FTP



## Install

This package has not yet been published to PyPi but can be installed directly by referencing the URL to the latest version on Github. 

See: [Github Releases](https://github.com/mmongeon-sym/pipy/releases)

#### Install from Github (Latest Version)
```bash
pip install https://github.com/mmongeon-sym/boxy/releases/latest/download/boxy.tar.gz
```

#### Uninstall
```bash
pip uninstall boxy
```

## Usage

#### Import
```bash
from pipy import Pipy
```

