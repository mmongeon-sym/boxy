import dataclasses

import dataclasses
import ftplib
import pathlib

from .datetime import datetime_to_ftptime, parse_time
from .logging import disable_java_logging
from .utils import humansize

disable_java_logging()
from .exceptions import FTPFolderExistsError, FTPFolderNotFoundError, BoxFolderExistsError, BoxFolderNotFoundError
import datetime

from .localFile import LocalFile
from .ftp import FTPMethods


class FTPFolderMethods(FTPMethods):
    ftp: ftplib.FTP_TLS = NotImplemented
    path: str = NotImplemented

    directory: str = NotImplemented
    name: str = NotImplemented

    bytes: int = NotImplemented
    size: str = NotImplemented

    # md5: str = dataclasses.field(init=False)
    ctime: datetime.datetime = NotImplemented
    mtime: datetime.datetime = NotImplemented
    exists: bool = NotImplemented
    type: str = NotImplemented

    _is_box: bool = NotImplemented

    def __init__(self, ftp: ftplib.FTP_TLS, path: str, obj: tuple):

        raise NotImplementedError

    def __repr__(self,
                 size: bool = True,
                 mtime: bool = False,
                 ctime: bool = False,
                 exists: bool = True
                 ):
        if self.exists is True:
            msgs = []
            if exists is True and self.exists is not None:
                msgs.append(f"exists={self.exists}")
            if size is True and self.size is not None:
                msgs.append(f"size='{self.size}'")
            if mtime is True and self.mtime is not None:
                msgs.append(f"mtime='{self.mtime}'")
            if ctime is True and self.ctime is not None:
                msgs.append(f"ctime='{self.ctime}'")

            if len(msgs) > 0:
                msgs_str = ", ".join(msgs)
                return f"{self.__class__.__name__}('{self.path}', {msgs_str})"
            else:
                return f"{self.__class__.__name__}('{self.path}')"
        else:
            return f"{self.__class__.__name__}('{self.path}', exists=False)"

            # return f"FTPFile('{self.path}', exists={self.exists})"

    def __str__(self,
                size: bool = True,
                mtime: bool = False,
                ctime: bool = False,
                exists: bool = True
                ):
        return self.__repr__(
                size=True,
                mtime=False,
                ctime=False,
                exists=True
                )

    def __post_init__(self, obj: tuple):
        raise NotImplementedError

    def initialize(self, obj: tuple):
        parts = pathlib.PurePosixPath(self.path)
        self.directory = str(parts.parent)
        self.name = str(parts.name)
        self.extension = str(parts.suffix)

        if obj is None:
            obj = self._get_raw_object(ftp=self.ftp, path=self.path, type='dir')

        self.exists = False
        if obj is not None:
            assert obj[0] == self.name
            assert obj[1]['type'] == 'dir'

            assert 'modify' in obj[1]
            assert 'create' in obj[1]
            if obj[1]['modify'] != '19700131000000.000' and obj[1]['create'] != '19700131000000.000':
                self.exists = True
            self.bytes = int(obj[1]['size'])
            self.size = humansize(self.bytes)
            self.ctime = parse_time(obj[1]['create'])
            self.mtime = parse_time(obj[1]['modify'])

    @classmethod
    def from_obj(cls,
                 ftp: ftplib.FTP_TLS,
                 obj: tuple,
                 parent_dir: str
                 ):
        """

        from an ftplib.File object
            ex. ('Sapphire End User Documentation',
                    {   'size': '7327748',
                        'modify': '20191018204619.000',
                        'create': '20180412221908.000',
                        'type': 'dir'
                    }
                )

        :param ftp:
        :param obj:
        :param parent_dir:
        :return:
        """

        assert obj[1]['type'] == 'dir'
        if parent_dir[-1] != "/":
            parent_dir = parent_dir + "/"
        path = parent_dir + obj[0]

        return cls(ftp=ftp,
                   path=path,
                   obj=obj
                   )

    @classmethod
    def from_path(cls,
                  ftp: ftplib.FTP_TLS,
                  path: str
                  ):
        obj = cls._get_raw_object(ftp=ftp, path=path, type='dir')
        return cls(ftp=ftp, path=path, obj=obj)

    def to_obj(self):
        return (self.name, {
                'create': datetime_to_ftptime(self.ctime),
                'modify': datetime_to_ftptime(self.mtime),
                'type':   'dir',
                'size':   str(self.bytes)
                }
                )

    def refresh(self, obj: tuple):
        self.clear()
        self.__post_init__(obj=obj)

        return self

    def reset(self):
        return self.clear()

    def clear(self):
        self.exists = False
        self.size = humansize(0)
        self.bytes = 0
        self.ctime = parse_time('19700131000000.000')
        self.mtime = parse_time('19700131000000.000')
        return self

    def copy_obj(self):
        if self._is_box is True:
            return BoxFolder(ftp=self.ftp, path=self.path, obj=self.to_obj())
        else:
            return FTPFolder(ftp=self.ftp, path=self.path, obj=self.to_obj())

    def assert_exists(self):
        if self.exists is False:
            if self._is_box is True:
                raise BoxFolderNotFoundError(self.path)
            else:
                raise FTPFolderNotFoundError(self.path)

    def assert_not_exists(self):
        if self.exists is True:
            if self._is_box is True:
                raise BoxFolderExistsError(self.path)
            else:
                raise FTPFolderExistsError(self.path)

    def file(self, name: str):
        if self.directory == "/" and self.path == "/":
            path = self.directory + name
        else:
            path = self.path + "/" + name
        if self._is_box is True:
            return BoxFile.from_path(ftp=self.ftp, path=path)
        else:
            return FTPFile.from_path(ftp=self.ftp, path=path)

    def folder(self, name: str):
        if self.directory == "/" and self.path == "/":
            path = self.directory + name
        else:
            path = self.path + "/" + name
        if self._is_box is True:
            return BoxFolder.from_path(ftp=self.ftp, path=path)
        else:
            return FTPFolder.from_path(ftp=self.ftp, path=path)

    def files(self, path: str = None):
        if path is None:
            path = self.path
        return self._list_files(ftp=self.ftp, path=path, is_box=self._is_box)

    def folders(self, path: str = None):
        if path is None:
            path = self.path
        return self._list_dirs(ftp=self.ftp, path=path, is_box=self._is_box)

    def list(self,
             path: str = None
             ):
        if path is None:
            path = self.path
        return self._list_objs(ftp=self.ftp, path=path, is_box=self._is_box)

    def upload_file(self,
                    path: str,
                    name: str = None
                    ):
        local_file = LocalFile(path)
        if name is None:
            name = local_file.name
        local_file.assert_exists()
        if self.directory == "/" and self.path == "/":
            remote_path = self.directory + name
        else:
            remote_path = self.path + "/" + name
        return self._upload_file(ftp=self.ftp,
                                 remote_path=remote_path,
                                 local_path=local_file.path,
                                 remote_file=self,
                                 is_box=self._is_box)

    def download_file(self,
                      name: str,
                      path: str = None
                      ):
        local_file = LocalFile(path)
        if self.directory == "/" and self.path == "/":
            remote_path = self.directory + name
        else:
            remote_path = self.path + "/" + name
        return self._download_file(ftp=self.ftp, local_path=local_file.path, remote_path=remote_path,
                                   is_box=self._is_box)

    def download_temp_file(self,
                           ftp: ftplib.FTP_TLS,
                           remote_path: str,
                           remote_file=None,
                           set_ctime=False,
                           set_mtime=True,
                           is_box: bool = False):

        return self._download_temp_file(ftp=self.ftp, remote_path=remote_path,
                                        is_box=self._is_box)



@dataclasses.dataclass(init=True, repr=False, eq=True, order=True, unsafe_hash=False, frozen=False)
class FTPFolder(FTPFolderMethods):
    ftp: ftplib.FTP_TLS = dataclasses.field(init=True)
    path: str = dataclasses.field(init=True)

    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)

    bytes: int = dataclasses.field(init=False, default=0)
    size: str = dataclasses.field(init=False, default=humansize(0))

    ctime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    mtime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    exists: bool = dataclasses.field(init=False, default=None)
    type: str = dataclasses.field(init=False, default='dir')

    obj: dataclasses.InitVar[tuple] = None

    _is_box = False

    def __post_init__(self,
                      obj: tuple
                      ):
        self.initialize(obj=obj)

    def __iter__(self):
        return iter(self.list(path=self.path))
