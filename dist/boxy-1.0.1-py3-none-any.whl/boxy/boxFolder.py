import dataclasses
import datetime
import ftplib

from .datetime import parse_time
from .ftpFolder import FTPFolder
from .utils import humansize


@dataclasses.dataclass(init=True, repr=False, eq=True, order=True, unsafe_hash=False, frozen=False)
class BoxFolder(FTPFolder):
    ftp: ftplib.FTP_TLS = dataclasses.field(init=True)
    path: str = dataclasses.field(init=True)

    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)
    extension: str = dataclasses.field(init=False)

    bytes: int = dataclasses.field(init=False, default=0)
    size: str = dataclasses.field(init=False, default=humansize(0))

    ctime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    mtime: datetime.datetime = dataclasses.field(init=False, default=parse_time('19700131000000.000'))
    exists: bool = dataclasses.field(init=False, default=None)
    type: str = dataclasses.field(init=False, default='dir')

    obj: dataclasses.InitVar[tuple] = None

    _is_box = True

    def __post_init__(self,
                      obj: tuple
                      ):
        self.initialize(obj=obj)
