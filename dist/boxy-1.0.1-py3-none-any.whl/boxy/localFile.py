
import dataclasses
import os
import pathlib
import shutil

from .datetime import parse_time, parse_unix_ts
from .logging import disable_java_logging, get_logger
from .timer import Timer
from .utils import humansize

disable_java_logging()
import datetime
from .exceptions import FTPFileExistsError


@dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=False, frozen=False)
class LocalFile(object):
    path: str = dataclasses.field(init=True)
    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)
    exists: bool = dataclasses.field(init=False)
    size: str = dataclasses.field(init=False)
    bytes: int = dataclasses.field(init=False)
    extension: str = dataclasses.field(init=False)
    ctime: datetime.datetime = dataclasses.field(init=False)
    mtime: datetime.datetime = dataclasses.field(init=False)
    _md5: str = dataclasses.field(init=False, default=None)

    log = get_logger()

    def __repr__(self,
                 size=True,
                 mtime=False,
                 ctime=False,
                 exists=True
                 ):
        if self.exists is True:
            msgs = []
            if exists is True and self.exists is not None:
                msgs.append(f"exists={self.exists}")
            if size is True and self.size is not None:
                msgs.append(f"size='{self.size}'")
            if mtime is True and self.mtime is not None:
                msgs.append(f"mtime='{self.mtime}'")
            if ctime is True and self.ctime is not None:
                msgs.append(f"ctime='{self.ctime}'")

            if len(msgs) > 0:
                msgs_str = ", ".join(msgs)
                return f"LocalFile('{self.path}', {msgs_str})"
            else:
                return f"LocalFile('{self.path}')"
        else:
            return f"{self.__class__.__name__}('{self.path}', exists=False)"

    def __str__(self,
                size=True,
                mtime=False,
                ctime=False,
                exists=True
                ):
        return self.__repr__(
                size=True,
                mtime=False,
                ctime=False,
                exists=True
                )

    def __post_init__(self):
        self.directory = os.path.dirname(self.path)
        self.name = pathlib.Path(self.path).name
        self.extension = pathlib.Path(self.path).suffix
        if os.path.exists(self.path) is True:
            stat = os.stat(self.path)
            self.exists = True
            self.size = humansize(stat.st_size)
            self.bytes = stat.st_size
            if hasattr(stat, 'st_ctime'):
                self.ctime = parse_unix_ts(getattr(stat, 'st_ctime'))
            if hasattr(stat, 'st_birthtime') is True and getattr(stat, 'st_birthtime') is not None:
                self.ctime = parse_unix_ts(getattr(stat, 'st_birthtime'))
            self.mtime = parse_unix_ts(stat.st_mtime)
        else:
            self.exists = False
            self.size = humansize(0)
            self.bytes = 0
            self.ctime = None
            self.mtime = None

    @property
    def md5(self):
        self.assert_exists()
        if self._md5 is not None:
            return self._md5
        else:
            self._md5 = MD5_file(path=self.path, mtime=self.mtime, bytes=self.bytes)
            return self._md5

    def refresh(self):
        self.__post_init__()

    def clear(self):
        self.exists = False
        self.size = humansize(0)
        self.bytes = 0
        self.ctime = parse_time('19700131000000.000')
        self.mtime = parse_time('19700131000000.000')

    def makedirs(self):
        if os.path.exists(self.directory) is False:
            os.makedirs(self.directory, exist_ok=True)

    def assert_exists(self):
        if self.exists is False:
            raise FileNotFoundError(self.path)

    def assert_not_exists(self):
        if self.exists is True:
            raise FileExistsError(self.path)

    def remove(self):
        if os.path.exists(self.path) is True:
            os.remove(self.path)
            if os.path.exists(self.path) is False:
                self.log.info(f"Removed: {self.__repr__(exists=False, size=True)}")
                self.refresh()
            else:
                self.log.error(f"Failed to remove: {self.__repr__(exists=True, size=True)}")
                raise FTPFileExistsError

    def read(self):
        self.assert_exists()
        with open(self.path, mode='r') as infile:
            string = infile.read()
        self.log.info(f"Read {len(string.splitlines())} lines from: {self.__repr__(exists=False, size=True)}")
        return string

    def readlines(self):
        string = self.read()
        return string.splitlines()

    def write(self, string):
        lines = str(string).splitlines()
        self.makedirs()
        with Timer() as t:
            with open(self.path, mode='w') as outfile:
                outfile.writelines(lines)
        self.refresh()
        t.stop(n_bytes=self.bytes, n_items=len(lines), item_name='lines')
        self.log.info(f"Wrote {len(lines)} lines,"
                      f" {len(string)} chars "
                      f"to: {self.__repr__(exists=False, size=True)} "
                      f"in '{t.duration_str}', '{t.bytes_per_second_str}', '{t.items_per_second_str}'")

    def writelines(self, lines):
        self.makedirs()
        with Timer() as t:
            with open(self.path, mode='w') as outfile:
                outfile.writelines(lines)
        self.refresh()
        t.stop(n_bytes=self.bytes, n_items=len(lines), item_name='lines')
        self.log.info(f"Wrote {len(lines)} lines "
                      f"to: {self.__repr__(exists=False, size=True)} "
                      f"in '{t.duration_str}', '{t.bytes_per_second_str}', '{t.items_per_second_str}'")

    def rename(self, name):
        new_path = os.path.join(self.directory, name)
        shutil.move(self.path, os.path.join(self.directory, name), copy_function=shutil.copy2)
        new_file = LocalFile(path=new_path)
        if new_file.exists is True:
            return self.log.info(f"Renamed {self.__repr__(exists=False, size=False)} "
                                 f"to {new_file.__repr__(exists=False, size=False)}")
        else:
            self.log.error(f"Failed to rename {self.__repr__(exists=False, size=False)} "
                           f"to {new_file.__repr__(exists=False, size=False)}")
            raise FileNotFoundError(new_path)

    def move(self, new_path):
        parts = pathlib.Path(new_path)
        directory = parts.parent
        filename = parts.name

        shutil.move(self.path, os.path.join(directory, filename), copy_function=shutil.copy2)
        new_file = LocalFile(path=new_path)
        if new_file.exists is True:
            return self.log.info(f"Moved {self.__repr__(exists=False, size=False)} "
                                 f"to {new_file.__repr__(exists=False, size=False)}")
        else:
            self.log.error(f"Failed to move {self.__repr__(exists=False, size=False)} "
                           f"to {new_file.__repr__(exists=False, size=False)}")
            raise FileNotFoundError(new_path)

    def copy(self, path):
        parts = pathlib.Path(path)
        if os.path.exists(path) is True:
            os.remove(path)
        os.makedirs(parts.parent)
        shutil.copy2(self.path, path)
        new_file = LocalFile(path=path)
        if new_file.exists is True:
            return self.log.info(f"Copied {self.__repr__(exists=True, size=True)} "
                                 f"to {new_file.__repr__(exists=True)}")
        else:
            self.log.info(f"Failed to copy {self.__repr__(exists=True, size=True)} "
                          f"'to {new_file.__repr__(size=False, exists=False)}")

    def set_mtime(self, dt: datetime.datetime):
        t = dt.astimezone(tz=datetime.timezone.utc).timestamp()
        os.utime(self.path, times=(t, t))
        self.mtime = dt
        return self

    def set_ctime(self, dt: datetime.datetime):
        t = dt.astimezone(tz=datetime.timezone.utc).timestamp()
        os.utime(self.path, times=(t, t))
        self.mtime = dt
        return self
    def to_rdd(self, headers=True, inferSchema=True):
        """
        Return the result set as a DataFrame

        Parameters:

            index(:obj:`str`, optional): Column to be used as the index of the DataFrame, defaults to :obj:`None`



        """
        try:
            import pyspark
        except ModuleNotFoundError as error:
            raise error


        from pyspark.sql import SparkSession

        t = Timer()
        t.start()
        sc = SparkSession.builder.getOrCreate()
        sc.conf.set("spark.sql.execution.arrow.enabled", "true")
        parts = pathlib.PurePosixPath(self.path).parts[1]

        if pathlib.PurePosixPath(self.path).parts[1] == 'dbfs':
            dbfs_path = self.path.replace('/dbfs/', '')
        else:
            dbfs_path = self.path

        rdd = sc.read.format('csv').options(header=headers, inferSchema=inferSchema).load(dbfs_path)

        n_rows = rdd.count()
        n_cols = len(rdd.columns)
        t.stop(n_items=n_rows,
               n_bytes=self.bytes,
               item_name='rows'
               )
        self.log.info("Returned RDD({n_cols}x{n_rows}), "
                      "{bytes_str} in {duration}, "
                      "{bits_sec}, "
                      "{bytes_sec}, "
                      "{bytes_sec}".format(n_cols=n_rows,
                                           n_rows=n_cols,
                                           bytes_str=t.bytes_str,
                                           duration=t.duration,
                                           bits_sec=t.bits_per_second,
                                           bytes_sec=t.bytes_per_second_str,
                                           rows_sec=t.items_per_second_str
                                           ))


        return rdd

    def to_df(self, headers=True,
              columns: (bool, str, None, list, tuple) = None,
              parse_dates: (bool, str, None, list, tuple) =True,
              index_col: (str, None, list, tuple) = None):
        """
        Return the FTPFile as a Pandas DataFrame

        Parameters:

            index(:obj:`str`, optional): Column to be used as the index of the DataFrame, defaults to :obj:`None`

        Returns:
            :class:`pd.DataFrame`: Pandas DataFrame

        """

        # https://pandas.pydata.org/pandas-docs/version/0.24.2/reference/api/pandas.read_csv.html#pandas.read_csv
        try:
            import pandas as pd
        except ModuleNotFoundError as error:
            raise error


        if columns is not None and isinstance(columns, (list, tuple)) is True and len(columns) > 0:
            columns = columns
            usecols = columns
        else:
            columns = None
            usecols = None

        if headers is True:
            header = 'infer'
        if headers is False:
            header = 0
        else:
            header = 'infer'

        if parse_dates is True or (isinstance(parse_dates, (list, tuple)) is True and len(parse_dates) > 0):
            infer_datetime_format = True
        else:
            infer_datetime_format = False

        t = Timer()
        t.start()
        df = pd.read_csv(self.path, sep=',',
                         header=header,
                         names=columns,
                         usecols=usecols,
                         index_col=index_col,
                         parse_dates=parse_dates,
                         infer_datetime_format=infer_datetime_format,
                         memory_map=True,
                         low_memory=False,
                         compression='infer'
                         )
        df.fillna(pd.np.nan, inplace=True)
        n_rows = df.shape[0]
        n_cols = len(df.columns)
        n_bytes = df.memory_usage(index=True, deep=False).sum()
        t.stop(n_items=int(n_rows),
               n_bytes=int(n_bytes),
               item_name='rows'
               )
        self.log.info("Returned DataFrame(cols={n_cols}, rows={n_rows}, size={bytes_str}) "
                      "in: '{duration}', '{bits_sec}', '{bytes_sec}', '{rows_sec}'".format(n_cols=n_cols,
                                                                                           n_rows=n_rows,
                                                                                           bytes_str=t.bytes_str,
                                                                                           duration=t.duration,
                                                                                           bits_sec=t.megabits_per_second_str,
                                                                                           bytes_sec=t.bytes_per_second_str,
                                                                                           rows_sec=t.items_per_second_str
                                                                                           ))

        return df

