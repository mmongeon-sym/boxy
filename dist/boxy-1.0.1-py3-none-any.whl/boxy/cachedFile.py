
import dataclasses
import datetime

from bad_boxy.localFile import LocalFile


@dataclasses.dataclass(init=True, repr=True, eq=True, order=True, unsafe_hash=False, frozen=False)
class CachedFile(LocalFile):
    path: str = dataclasses.field(init=True)
    directory: str = dataclasses.field(init=False)
    name: str = dataclasses.field(init=False)
    exists: bool = dataclasses.field(init=False)
    size: str = dataclasses.field(init=False)
    bytes: int = dataclasses.field(init=False)
    extension: str = dataclasses.field(init=False)
    ctime: datetime.datetime = dataclasses.field(init=False)
    mtime: datetime.datetime = dataclasses.field(init=False)
    _md5: str = dataclasses.field(init=False, default=None)

    def __repr__(self,
                 size=True,
                 mtime=False,
                 ctime=False,
                 exists=True
                 ):
        if self.exists is True:
            msgs = []
            if exists is True and self.exists is not None:
                msgs.append(f"exists={self.exists}")
            if size is True and self.size is not None:
                msgs.append(f"size='{self.size}'")
            if mtime is True and self.mtime is not None:
                msgs.append(f"mtime='{self.mtime}'")
            if ctime is True and self.ctime is not None:
                msgs.append(f"ctime='{self.ctime}'")

            if len(msgs) > 0:
                msgs_str = ", ".join(msgs)
                return f"{self.__class__.__name__}('{self.path}', {msgs_str})"
            else:
                return f"{self.__class__.__name__}('{self.path}')"
        else:
            return f"{self.__class__.__name__}('{self.path}', exists=False)"

    def __str__(self,
                size=True,
                mtime=False,
                ctime=False,
                exists=True
                ):
        return self.__repr__(
                size=True,
                mtime=False,
                ctime=False,
                exists=True
                )
